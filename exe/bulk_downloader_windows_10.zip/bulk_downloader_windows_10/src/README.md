
1. `pip install -r requirements.txt`
2. `python bulk_downloader.py`
