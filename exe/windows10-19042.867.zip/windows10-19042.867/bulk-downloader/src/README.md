follow the below two steps to get the program/utility running:

1. `pip install -r requirements.txt`
2. `python bulk_downloader.py`

__note__: if you encounter an error regarding tkinter (Tk) not being installed, such as

`ModuleNotFoundError: No module named 'tkinter'`

then follow the instructions at the url below.

https://tkdocs.com/tutorial/install.html

