#!/bin/bash

clear
echo "Running Bulk Downloader executable file located at /bulk-downloader/dist/bulk_downloader/bulk_downloader"
./bulk-downloader/dist/bulk_downloader/bulk_downloader
exit 0
